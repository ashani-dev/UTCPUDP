#pragma once
namespace UTCPUDP
{
	enum TCPUDP
	{
		Other,
		TCP,
		UDP
	};
}
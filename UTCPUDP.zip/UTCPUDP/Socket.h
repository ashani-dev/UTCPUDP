#pragma once
#include "SocketHandle.h"
#include "UResult.h"
#include "IPVersion.h"
#include "SocketOption.h"
#include "IPEndpoint.h"
#include "Constants.h"
#include "Packet.h"
#include "TCPUDP.h"

namespace UTCPUDP
{
	class Socket
	{
	public:
		Socket(	IPVersion ipversion = IPVersion::IPv4,
				SocketHandle handle = INVALID_SOCKET);
		UResult Create();
		UResult Close();
		UResult Bind(IPEndpoint endpoint);
		UResult Listen(IPEndpoint endpoint, int backlog = 5);
		UResult Accept(Socket & outSocket);
		UResult Connect(IPEndpoint endpoint);
		UResult Send(const void * data, int numberOfBytes, int & bytesSent);
		UResult Recv(void * destination, int numberOfBytes, int & bytesReceived);
		UResult SendAll(const void * data, int numberOfBytes);
		UResult RecvAll(void * destination, int numberOfBytes);
		UResult Send(Packet & packet);
		UResult Recv(Packet & packet);
		SocketHandle GetHandle();
		IPVersion GetIPVersion();
		void SetUDP(bool EnableUDP);
		TCPUDP GetProtocol();

	private:
		UResult SetSocketOption(SocketOption option, BOOL value, TCPUDP protocol);
		IPVersion ipversion = IPVersion::IPv4;
		SocketHandle handle = INVALID_SOCKET;
		TCPUDP protocolType = TCPUDP::TCP;
		
	};
}
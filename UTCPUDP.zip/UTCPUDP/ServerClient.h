#pragma once
#include "IncludeMe.h"
#include "Connections.h"

using namespace UTCPUDP;

namespace UTCPUDP
{
	class ServerClient
	{
	public:
		bool Initialize(IPEndpoint ip);
		void Frame();
	protected:
		virtual void OnConnect(Connection& newConnection);
		virtual void OnDisconnect(Connection& lostConnection, std::string reason);
		void CloseConnection(int connectionIndex, std::string reason);
		virtual bool ProcessPacket(std::shared_ptr<Packet> packet);

		Socket listeningSocket;
		std::vector<Connection> connections;
		std::vector<WSAPOLLFD> master_fd;
		std::vector<WSAPOLLFD> use_fd;
	};
}
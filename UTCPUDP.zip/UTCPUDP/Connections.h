#pragma once
#include "Socket.h"
#include "Protocol.h"

namespace UTCPUDP
{
	class Connection
	{
	public:
		Connection(Socket socket, IPEndpoint endpoint);
		Connection() :socket(Socket()) {}
		void Close();
		std::string ToString();
		Socket socket;
#if 0
		PacketManager pm_incoming;
		PacketManager pm_outgoing;
		char buffer[PNet::g_MaxPacketSize];
		bool simpleTransmissionMode = false; //simple transmission = text only (for dcs)
#endif

	private:
		IPEndpoint endpoint;
		std::string stringRepresentation = "";
	};
}
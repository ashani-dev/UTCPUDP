#include "Connections.h"

UTCPUDP::Connection::Connection(Socket socket, IPEndpoint endpoint)
{
}
#pragma once

namespace UTCPUDP
{
	const int g_MaxPacketSize = 8192;
}
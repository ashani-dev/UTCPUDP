#pragma once

namespace UTCPUDP
{
	enum IPVersion
	{
		Unknown,
		IPv4,
		IPv6
	};
}
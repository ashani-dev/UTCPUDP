#pragma once

namespace UTCPUDP
{
	enum UResult
	{
		P_Success,
		P_GenericError
	};
}
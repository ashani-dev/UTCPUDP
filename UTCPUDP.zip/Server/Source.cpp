//Server Code [Tutorial 17]
//Author: Jacob Preston 2019-04-26

#include <UTCPUDP\IncludeMe.h>
#include <iostream>

using namespace UTCPUDP;

bool ProcessPacket(Packet & packet)
{
	switch (packet.GetPacketType())
	{
	case PacketType::PT_ChatMessage:
	{
		std::string chatmessage;
		packet >> chatmessage;
		std::cout << "Chat Message: " << chatmessage << std::endl;
		break;
	}
	case PacketType::PT_IntegerArray:
	{
		uint32_t arraySize = 0;
		packet >> arraySize;
		std::cout << "Array Size: " << arraySize << std::endl;
		for (uint32_t i = 0; i < arraySize; i++)
		{
			uint32_t element = 0;
			packet >> element;
			std::cout << "Element[" << i << "] - " << element << std::endl;
		}
		break;
	}
	default:
		return false;
	}

	return true;
}

int main()
{
	
	if (Network::Initialize())
	{
		std::cout << "Winsock api successfully initialized." << std::endl;

		Socket socket(IPVersion::IPv6); 
		socket.SetUDP(1);
		if (socket.Create() == UResult::P_Success)
		{
			std::cout << "Socket successfully created." << std::endl;
			if (socket.Listen(IPEndpoint("::1", 4790)) == UResult::P_Success)
			{
				std::cout << "Socket successfully listening on port 4790." << std::endl;
				Socket newConnection;
				if (socket.Accept(newConnection) == UResult::P_Success)
				{
					std::cout << "New connection accepted." << std::endl;

					Packet packet;
					INT8 mArray[100];
					int cnt = 0;
					while (true)
					{
						//UResult result = newConnection.Recv(packet);
						UResult result = newConnection.RecvAll(&mArray,10);
						if (result != UResult::P_Success)
							break;
						std::cout << "Received Data: In Loop count: "<<cnt<< " ";
						for (int i = 0; i < 10; i++) { std::cout << (int)mArray[i] << ", "; }
						std::cout << std::endl;
						cnt++;
						//if (!ProcessPacket(packet))
							//break;
					}

					newConnection.Close();
				}
				else
				{
					std::cerr << "Failed to accept new connection." << std::endl;
				}
			}
			else
			{
				std::cerr << "Failed to listen on port 4790." << std::endl;
			}
			socket.Close();
		}
		else
		{
			std::cerr << "Socket failed to create." << std::endl;
		}
	}
	Network::Shutdown();
	system("pause");
	return 0;
}